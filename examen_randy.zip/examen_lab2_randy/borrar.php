  <?php

  include "conectardb.php";
  if(isset($_GET['id'])){
    if(is_null( $_GET['id']) || $_GET['id']=="") {
  echo "se ha encontrado un problema";

  }else {
    $sql = "DELETE FROM consultas WHERE id=".$_GET['id'];

  if (mysqli_query($conn, $sql)) {
    echo "<script>";
    echo "alert('";
      echo "registro borrado!";
      echo "');";
      echo "</script>";
      header("location: index.php");

  } else {
      echo "error al borrar " . mysqli_error($conn);
  }

  mysqli_close($conn);
  }
  }
  $id = $_GET['id'];
   ?>
