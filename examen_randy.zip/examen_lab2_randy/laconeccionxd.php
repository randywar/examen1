<?php
$servername = "localhost";
$username = "root";
$password = "123456";
$dbname = "patito";

// Create connection
$connn = mysqli_connect($servername, $username, $password,$dbname);
// Check connection
if (!$connn) {
   die("Conexión fallida: " . mysqli_connect_error());
}
echo "Conectado correctamente";
?>
