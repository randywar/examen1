<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form action="login.php" method="post">
      <input type="text" name="usuario" placeholder="usuario" value="">
      <input type="password" name="password" value="">
      <input type="submit" name="" value="enviar">
    </form>
  </body>
</html>
<?php
if(isset($_POST['usuario'])){
  include 'laconeccionxd.php';
  $sql = "SELECT count(usuario) as conteo from usuarios where
  usuario='{$_POST['usuario']}' and password ='{$_POST['password']}';";

  $query = mysqli_query($connn,$sql);
  $resultado = mysqli_fetch_assoc($query);
  if($resultado['conteo']==1){
    session_start();
    $_SESSION['usuario'] = $_POST['usuario'];
    header("location: index.php");
  } else {
    session_start();
    $_SESSION['usuario'] = null;
  }
}
 ?>
