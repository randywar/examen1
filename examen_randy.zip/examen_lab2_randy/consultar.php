<!DOCTYPE html>
<html lang="es" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h1>Consultar personas por medio de su sexo (masculino o femenino)</h1>
    <form action="consultar.php" method="post">
      <input type="text" name="search" placeholder="buscar">
      <input type="submit" name="buscar" value="buscar"><br>
    </form>
  </body>
</html>
<!--  ?> -->
<?php

 if (isset($_POST['buscar']))
{
   $buscar=$_POST['search'];
   include "conectardb.php";
  $resulto = mysqli_query($conn,"SELECT * FROM consultas where sexo = '$buscar'");
      while($consult = mysqli_fetch_array($resulto))
      {
        echo
           "
             <table width=\"100%\" border=\"1\">
               <tr>
                 <td><b><center>id</center></b></td>
                 <td><b><center>fecha</center></b></td>
                 <td><b><center>nombre</center></b></td>
                 <td><b><center>sintomas</center></b></td>
                 <td><b><center>receta</center></b></td>
               </tr>
               <tr>
                 <td>".$consult['id']."</td>
                 <td>".$consult['fecha']."</td>
                 <td>".$consult['nombre']."</td>
                 <td>".$consult['sintomas']."</td>
                 <td>".$consult['receta']."</td>
               </tr>
             </table>
           ";
      }

    }

     ?>
