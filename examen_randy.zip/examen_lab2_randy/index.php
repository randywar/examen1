<?php
include "conectardb.php"
 ?>
<!DOCTYPE html>
<html lang="es" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>clinica</title>
  </head>
  <body>
  <center><p ><b>paa registrar una nueva consulta precione <a href="crear.php"> AQUI </a><br><br> </center>

<hr width="100% "/>

    <?php
      $sql = "SELECT id as correlativo, nombre,edad FROM consultas";
      $result = mysqli_query($conn, $sql);

      if (mysqli_num_rows($result) > 0) {
          // output data of each row
          while($row = mysqli_fetch_assoc($result)) {
              echo "pasiente" . $row["correlativo"]. " - Nombre: " .$row["nombre"]. "-edad:". $row["edad"]." - <a href=\"actualizar.php?id=".$row["correlativo"]."\">modificar</a>"." <br>";
          }
      } else {
          echo "0 results";
      }

    mysqli_close($conn); ?>
  </b></p>
  </body>
</html>
