
<?php include "formulario.php" ?>

<?php
include "conectardb.php"
?>

<?php
// ver que el usuario no mando vacio el form
if (isset($_POST["boton"])) {
  if(is_null($_POST["boton"])  || $_POST["boton"]=="" ){

  }else {
    $sql = "INSERT INTO consultas (fecha,nombre,edad,sexo,sintomas,receta)
    VALUES ('".$_POST[fecha]."','".$_POST[nombre]."','".$_POST[edad]."','".$_POST[sexo]."','".$_POST[sintomas]."','".$_POST[receta]."')";

    if (mysqli_query($conn, $sql)) {
        header("location: index.php");
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    mysqli_close($conn);

}
}


 ?>
