<!DOCTYPE html>
<html lang="es" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <center><h1>datos de registro</h1></center>

      <center>
        <form method="POST" action="" >
          <label for="fec">Fecha:</label>
          <input type="date" name="fecha" placeholder="fecha" >
          <br><br>

          <label for="nom">Nombre:</label>
          <input type="text" name="nombre" placeholder="nombre de paciente" >
          <br><br>

          <label for="edad">Edad:</label>
          <input type="text" name="edad" placeholder="edad del pasiente">
          <br><br>

          <label for="sex">Sexo:</label>
          <input type="text" name="sexo" placeholder="masculino o femenino">
          <br><br>

          <label for="sin">sintomas:</label>
          <input type="text" name="sintomas" placeholder="sintomas del pasiente" >
          <br><br>

          <label for="rec">Receta:</label>
          <input type="text" name="receta" placeholder="receta para el pasiente">
          <br><br>

          <input type="submit" value="guardar registro"  name="boton">
          <input type="submit" value="Consultar" name="boton1">
        </form>
      </center>
  </body>
</html>
<?php
if(isset($_POST['boton1']))
    {
      header('location: consultar.php');
    }
    ?>
<?php
//$txt = fopen("con.text","a+") or die("error");
//fwrite($txt, $_POST["fecha"],$_POST["nombre"],$_POST["edad"],$_POST["sexo"],$_POST["sintomas"],$_POST["receta"]);
//fwrite($txt, "\n");
//fclose($txt);
 ?>
